PnL Lens — your data export

pnl-lens-data.json   everything PnL Lens holds about you: account, plans, payments, consents,
                     reports (with every trade, metric and habit), the list of your statements,
                     who accessed your files and when, and your account activity.
statements/          the original files you uploaded that are still stored
                     (files are deleted automatically 30 days after upload).

Questions: support@pnllens.com
